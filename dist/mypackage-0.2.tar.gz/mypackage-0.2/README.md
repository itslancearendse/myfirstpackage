## Purpose of this document
# To learn how to use GitHub.